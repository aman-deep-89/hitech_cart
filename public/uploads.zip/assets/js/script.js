var customer_banner = '<div class="homeshop-card hide" id="homeshop-card">\
<div class="container">\
    <div class="d-flex align-items-end">\
        <img src="public/assets/images/logo/logo-sm.png" alt="" height="100" width="100">\
        <div class="ms-4">\
            <h4 class="mb-2">Hitech Billing Software</h4>\
            <div class="d-flex">\
                <div class="text-muted pe-3">GST NO. <b>27AGHY500MJU</b></div> |\
                <div class="text-dark ps-3"><i class="bi-geo-alt-fill"></i> Nagpur MH-India-441107</div>\
            </div>\
            <div class="input-group w-50 mt-1">\
                <span class="input-group-text" id="basic-addon1"><i class="bi-telephone"></i></span>\
                <input type="text" class="form-control form-control-sm" disabled value="+91 8569542359" aria-label="Username" aria-describedby="basic-addon1">\
            </div>\
        </div>\
        <div class="destination ms-auto "></div>\
    </div>\
</div>\
</div>';

$(".customer-banner").html(customer_banner);

$(document).ready(function () {
    $(".count-input").hide();
    var count = 0;
    $('.increamentbtn').click(function () {
        var countInput = $(this).siblings('input');
        count++;
        countInput.attr("value", count);
    });

    $('.decreamentbtn').click(function () {
        var countInput = $(this).siblings('input');
        count--;
        countInput.attr("value", count);
        if (count <= 0) {
            countInput.parent().siblings().closest(".cart-btn").show();
            $(this).parent('.count-input').hide();
            $(this).parent().addClass("d-none").removeClass("d-flex");
        }
        if (count == 0) {
            count = 0;
            countInput.attr("value", count);
        }

    });

    $('.cart-btn').click(function () {
        $(this).hide();
        $(this).prev(".count-input").addClass("d-flex").removeClass("d-none");
    });

    $(".pickup-section").hide();
    $("#delivery").click(function () {
        $(".delivery-section").show();
        $(".pickup-section").hide();
    });

    $("#pickup").click(function () {
        $(".delivery-section").hide();
        $(".pickup-section").show();
    });

});


var jsonObj = {
    "index": { "y1": 300, "y2": 2900 },
    "product-details": { "y1": 60 }
};
var y2 = jsonObj["index"]["y2"];

if (window.location.href.indexOf("index") > -1) {
    y1 = jsonObj["index"]["y1"];
}

else if (window.location.href.indexOf("product-details") > -1 ||
    window.location.href.indexOf("order-details") > -1 ||
    window.location.href.indexOf("cart") > -1 ||
    window.location.href.indexOf("place-order") > -1) {
    y1 = jsonObj["product-details"]["y1"];
}

// Scroll to see pricing
myID = document.getElementById("homeshop-card");

var myScrollFunc = function () {
    var y = window.scrollY;

    if (y <= y1) {
        myID.className = "homeshop-card hide"
        $(".cart-wrapper").appendTo(".cart-parent");
    } else if (y >= y2) {
        myID.className = "homeshop-card hide"
        $(".cart-wrapper").appendTo(".cart-parent");
    } else {
        myID.className = "homeshop-card show"
        $(".cart-wrapper").appendTo(".destination");
    }
};

window.addEventListener("scroll", myScrollFunc);



// Product Image Magnifier

function imageZoom(imgID, resultID) {
    var img, lens, result, cx, cy;
    img = document.getElementById(imgID);
    result = document.getElementById(resultID);
    /*create lens:*/
    lens = document.createElement("DIV");
    lens.setAttribute("class", "img-zoom-lens");
    /*insert lens:*/
    img.parentElement.insertBefore(lens, img);
    /*calculate the ratio between result DIV and lens:*/
    cx = result.offsetWidth / lens.offsetWidth;
    cy = result.offsetHeight / lens.offsetHeight;
    /*set background properties for the result DIV:*/
    result.style.backgroundImage = "url('" + img.src + "')";
    result.style.backgroundSize = (img.width * cx) + "px " + (img.height * cy) + "px";
    /*execute a function when someone moves the cursor over the image, or the lens:*/
    lens.addEventListener("mousemove", moveLens);
    img.addEventListener("mousemove", moveLens);
    /*and also for touch screens:*/
    lens.addEventListener("touchmove", moveLens);
    img.addEventListener("touchmove", moveLens);
    function moveLens(e) {
        var pos, x, y;
        /*prevent any other actions that may occur when moving over the image:*/
        e.preventDefault();
        /*get the cursor's x and y positions:*/
        pos = getCursorPos(e);
        /*calculate the position of the lens:*/
        x = pos.x - (lens.offsetWidth / 2);
        y = pos.y - (lens.offsetHeight / 2);
        /*prevent the lens from being positioned outside the image:*/
        if (x > img.width - lens.offsetWidth) { x = img.width - lens.offsetWidth; }
        if (x < 0) { x = 0; }
        if (y > img.height - lens.offsetHeight) { y = img.height - lens.offsetHeight; }
        if (y < 0) { y = 0; }
        /*set the position of the lens:*/
        lens.style.left = x + "px";
        lens.style.top = y + "px";
        /*display what the lens "sees":*/
        result.style.backgroundPosition = "-" + (x * cx) + "px -" + (y * cy) + "px";
    }
    function getCursorPos(e) {
        var a, x = 0, y = 0;
        e = e || window.event;
        /*get the x and y positions of the image:*/
        a = img.getBoundingClientRect();
        /*calculate the cursor's x and y coordinates, relative to the image:*/
        x = e.pageX - a.left;
        y = e.pageY - a.top;
        /*consider any page scrolling:*/
        x = x - window.pageXOffset;
        y = y - window.pageYOffset;
        return { x: x, y: y };
    }
}


